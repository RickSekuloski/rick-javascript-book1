//Comments in JavaScript

// Single Line comment
/* 
Multi-line comment 
Multi-line comment can be also used as single line comments.

*/