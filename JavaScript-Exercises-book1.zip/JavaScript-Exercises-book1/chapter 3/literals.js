//Literals

2 // Number literal
2.5 // The number two point five, a valid number literal
"Hi there!" // String in double quotes
'Hi' // String in single quote
"" // Empty string
true // Boolean value not a string
false // Another boolean value not a string
null // special value
undefined // another special value
Symbol //new primitive 

