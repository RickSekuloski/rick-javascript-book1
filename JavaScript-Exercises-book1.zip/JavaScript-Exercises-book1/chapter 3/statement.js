//Statements 
let firstName = 'Rick ';
let lastName = 'Sekuloski';
alert(firstName + lastName);

//grouping the statements
let number1 = 4; let number2 = 5;

//Semicolon when we have a line break
let priceInDollars
priceInDollars = 59.4
console.log(priceInDollars)

/*JavaScript Interpret this as:

let priceInDollars; priceInDollars = 59.4; console.log(priceInDollars);