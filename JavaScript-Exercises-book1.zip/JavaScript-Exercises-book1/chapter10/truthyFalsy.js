
//Truthy & falsy values in JavaScript

let a = 1;// Variable a from type number
a = '1'; // Variable a is now from type string
a = [1]; //Variable a is now from type array

//true
1 == '1'; // true
1 == [1]; //true
'1' == [1]; // true


