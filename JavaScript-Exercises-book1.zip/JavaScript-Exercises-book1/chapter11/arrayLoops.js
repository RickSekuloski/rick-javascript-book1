const array = ['a', 'b', 'c', 'd','e','f','g'];

for (const index in array) {
	console.log(array[index])
}

//for in with strings
const string = 'Tom Cruise';

for (const index in string) {
    console.log(string[index])
}