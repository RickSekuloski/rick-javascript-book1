// change the h1 text color
const h1 = document.querySelector('.heading');
//add new color to the text
h1.style.color = "#FF5733";
//alignt the h1 to center
h1.style.textAlign = "center";
//adding padding on h1
h1.style.padding = "3rem";

// change the the paragraph
paragraph = document.querySelector("p");
// background color and add
paragraph.style.backgroundColor = "LightCoral";
// some padding
paragraph.style.padding = "3rem";
//change the color of the text
paragraph.style.color = "white";


