//Switch Statement

//check if a number is in the range from 1 to 10
let x = 11;

switch(x){
    case 1: // if x === 1
        //Execute the statements for case #1
        console.log('We have found the number ' + x);
        break; // Stop

    case 2: // if x === 2
       //Execute the statements for case #2
        console.log('We have found the number ' + x);
        break; // Stop

    case 3: // if x === 3
        //Execute the statements for case #3
        console.log('We have found the number ' + x);
        break; // Stop

    case 4: // if x === 4
        //Execute the statements for case #4
        console.log('We have found the number ' + x);
        break; // Stop

    case 5: // if x === 5
         //Execute the statements for case #5
        console.log(x);
        console.log('We have found the number ' + x);
        break; // Stop

    case 6: // if x === 6
        //Execute the statements for case #6
        console.log('We have found the number ' + x);
        break; // Stop

    case 7: // if x === 7
        //Execute the statements for case #7
        console.log('We have found the number ' + x);
        break; // Stop

    case 8: // if x === 8
        //Execute the statements for case #8
        console.log('We have found the number ' + x);
        break; // Stop

    case 9: // if x === 9
        //Execute the statements for case #9
        console.log('We have found the number ' + x);
        break; // Stop

    case 10: // if x === 10
        //Execute the statements for case #10
        console.log('We have found the number ' + x);
        break; // Stop

    default:
        //Execute the statements 
        console.log('The number is not in the range between 1 - 10: and the number is: ' + x)
        break;
}

console.log(`This is printed after the break statement terminated the switch statement`);