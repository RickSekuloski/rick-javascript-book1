//Conditional (ternary) operator
let age = 26;
let whichBevarage = (age >= 21) ? "Beer" : "Juice";
console.log(whichBevarage); // "Beer"
