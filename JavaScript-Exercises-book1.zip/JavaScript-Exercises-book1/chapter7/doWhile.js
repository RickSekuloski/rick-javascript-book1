//Do while, the code will be execuetd regardless of the confition

let i = 11;

do{
    console.log('The value of i:', i);
}while(i < 10);