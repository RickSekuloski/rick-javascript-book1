//While loop
let i = 0;

while (i < 10) {
   i++;
   console.log(i);
  }