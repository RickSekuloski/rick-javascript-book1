//Function Expression

let greeting = function(name,lastName){
    return `Nice to see you again ${name} ${lastName} !`;
}
//invoke function expression
let theMessage = greeting('Luke', "Perry");
console.log(theMessage);

