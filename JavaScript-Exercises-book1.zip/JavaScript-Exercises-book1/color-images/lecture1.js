const x = 5;
const y = 3;

console.log( x*y );